/* 
expect errors & malfunctionality (it was made under an hour)
feel free to change anything in the code unless you don't break it 

Note: The obfuscation process is ultra slow (especially for bigger files) because: its calling the API through the main.lua (security pruposes)
*/
const { Client, GatewayIntentBits, EmbedBuilder, AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Presence } = require('discord.js');
const fs = require('fs');
const { spawn } = require('child_process');
const crypto = require('crypto');
const axios = require('axios');

const PREFIX = '.';
const TOKEN = 'MTQyNDAxMDIyNzAzNjE5MjkyOA.GQk7Ml.sWBIGyCz783Ua-jwRb0lyz6ZhzZCe8cJzYAT5A'; // token
// CDN files to run in any env
const V11 = 'https://t11v.icu/dropper/lua/luasec/LuaSec.V11.lua';
const PARSER = 'https://t11v.icu/dropper/lua/luasec/util/parser.py';

const bot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

const WL_ALLOWED = new Set([
  '1091592149105135686', 
  '922095744691892224'  
  // if u want to add more ids just follow the pattern ("ID",)
]);

const wlUsers = new Set();
const blUsers = new Set();

async function Download() {
  try {
    if (!fs.existsSync('main.lua')) {
      console.log('[LuaSec] Downloading main.lua...');
      const response = await axios.get(V11);
      fs.writeFileSync('main.lua', response.data);
      console.log('[LuaSec] main.lua downloaded successfully');
    }
    
    if (!fs.existsSync('parser.py')) {
      console.log('[LuaSec] Downloading parser.py...');
      const response = await axios.get(PARSER);
      fs.writeFileSync('parser.py', response.data);
      console.log('[LuaSec] parser.py downloaded successfully');
    }
  } catch (error) {
    console.error('[LuaSec] Error downloading required files:', error);
  }
}

function genHash() {
  return crypto.randomBytes(20).toString('hex');
}

function buildEmbed(title, description, color = 0x3498db, user = null) {
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setColor(color)
    .setURL('https://the11view.xyz')
    .setFooter({ text: 'Made @ the11view.xyz', iconURL: 'https://t11v.icu/host/ea86ec6e-e9f4-4e34-bfa5-b80dc0f2887a.png' })
    .setTimestamp();
  
  if (user) {
    embed.setAuthor({ 
      name: user.username, 
      iconURL: user.displayAvatarURL({ dynamic: true, size: 256 }) 
    });
  }
  
  return embed;
}

async function downloadFile(url, filePath) {
  const writer = fs.createWriteStream(filePath);
  const response = await axios({
    method: 'GET',
    url: url,
    responseType: 'stream'
  });
  
  response.data.pipe(writer);
  // quick pass check
  return new Promise((resolve, reject) => {
    writer.on('finish', resolve);
    writer.on('error', reject);
  });
}

bot.on('messageCreate', async message => {
  if (message.author.bot) return;
  
  if (!message.content.startsWith(PREFIX)) return;
  
  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();
  // im here stacking commands in funcs so its easily recalled later (it mostly saves space)
  switch (command) {
    case 'wl':
    case 'whitelist':
      await processWl(message);
      break;
      
    case 'bl':
    case 'blacklist':
      await processBl(message);
      break;
      
    case 'obf':
    case 'o':
    case 'obfuscate':
      await processObf(message);
      break;
      
    case 'help':
      await processHelp(message);
      break;
      
    case 'docs':
      await processDocs(message);
      break;
  }
});

async function processWl(message) {
  // LOCK: only the two configured Discord IDs can use the .wl command
  if (!WL_ALLOWED.has(message.author.id)) {
    return message.reply({ embeds: [buildEmbed('Permission Denied', 'You are not allowed to use the whitelist command.', 0xe74c3c)] });
  }
  
  const user = message.mentions.users.first();
  if (!user) {
    return message.reply({ embeds: [buildEmbed('Invalid User', 'Mention a valid user to whitelist.', 0xe67e22)] });
  }
  
  wlUsers.add(user.id);
  return message.reply({ embeds: [buildEmbed('User Whitelisted', `${user.toString()} can now use the obfuscator.`, 0x2ecc71)] });
}

async function processBl(message) {
  if (!wlUsers.has(message.author.id) && !message.member.permissions.has('ADMINISTRATOR')) {
    return message.reply({ embeds: [buildEmbed('Permission Denied', 'You can\'t blacklist users.', 0xe74c3c)] });
  }
  
  const user = message.mentions.users.first();
  if (!user) {
    return message.reply({ embeds: [buildEmbed('Invalid User', 'Mention a valid user to blacklist.', 0xe67e22)] });
  }
  
  blUsers.add(user.id);
  if (wlUsers.has(user.id)) wlUsers.delete(user.id);
  
  return message.reply({ embeds: [buildEmbed('User Blacklisted', `${user.toString()} can\'t use the obfuscator anymore.`, 0xe74c3c)] });
}

async function processObf(message) {
  if (!wlUsers.has(message.author.id) || blUsers.has(message.author.id)) {
    return message.reply({ embeds: [buildEmbed('Access Denied', 'You\'re not allowed to use this command.', 0xe74c3c)] });
  }
  
  if (message.attachments.size === 0) {
    return message.reply({ embeds: [buildEmbed('Missing File', 'Attach a .lua file to obfuscate.', 0xe67e22)] });
  }
  
  const attachment = message.attachments.first();
  
  if (!attachment.name.endsWith('.lua')) {
    return message.reply({ embeds: [buildEmbed('Invalid File', 'Only .lua files are supported.', 0xe67e22)] });
  }
  
  const warningEmbed = new EmbedBuilder()
    .setColor(0xff9900)
    .setTitle('⚠️ File Processing Warning')
    .setDescription('Your file will be temporarily uploaded to our servers for processing. After obfuscation, all temporary files will be automatically deleted.\n\n**Do you want to continue?**')
    .setAuthor({ 
      name: message.author.username, 
      iconURL: message.author.displayAvatarURL({ dynamic: true, size: 256 }) 
    })
    .setFooter({ text: 'Made @ the11view.xyz', iconURL: 'https://t11v.icu/host/ea86ec6e-e9f4-4e34-bfa5-b80dc0f2887a.png' })
    .setTimestamp();
  
  const confirmButton = new ButtonBuilder()
    .setCustomId('confirm_obfuscation')
    .setLabel('Start Obfuscation')
    .setStyle(ButtonStyle.Success)
    .setEmoji('✅');
  
  const cancelButton = new ButtonBuilder()
    .setCustomId('cancel_obfuscation')
    .setLabel('Cancel')
    .setStyle(ButtonStyle.Danger)
    .setEmoji('✖️');
  
  const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);
  
  const warningMessage = await message.reply({
    embeds: [warningEmbed],
    components: [row]
  });
  
  const collector = warningMessage.createMessageComponentCollector({
    time: 60000
  });
  // lock the decision to only the command user (legal stuff)
  collector.on('collect', async interaction => {
    if (interaction.user.id !== message.author.id) {
      return interaction.reply({ 
        content: 'You cannot use this button.', 
        ephemeral: true 
      });
    }
    
    if (interaction.customId === 'confirm_obfuscation') {
      await interaction.update({ 
        content: 'Obfuscation process started...', 
        embeds: [], 
        components: [] 
      });
      
      await Obfuscate(message, attachment);
    } else if (interaction.customId === 'cancel_obfuscation') {
      await interaction.update({ 
        content: 'Obfuscation cancelled.', 
        embeds: [], 
        components: [] 
      });
    }
  });
  
  collector.on('end', (collected, reason) => {
    if (reason === 'time') {
      warningMessage.edit({ 
        content: 'Obfuscation timed out.', // this is required so it prevents looping or breaking or memory fucking
        embeds: [], 
        components: [] 
      });
    }
  });
}

async function processHelp(message) {
  const helpEmbed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle('📚 LuaSec V11 - Help')
    .setDescription('Advanced Lua obfuscation tool for Lua Utilities.\n\n**Commands:**')
    .addFields(
      { name: `⚙️ \`${PREFIX}whitelist @user\``, value: 'Allow a user to use the obfuscator', inline: true },
      { name: `🚫 \`${PREFIX}blacklist @user\``, value: 'Revoke a user\'s access to the obfuscator', inline: true },
      { name: `🔐 \`${PREFIX}obfuscate\``, value: 'Obfuscate a .lua file (attachment required)', inline: true },
      { name: `📖 \`${PREFIX}docs\``, value: 'Get documentation link', inline: true }
    )
    .addFields(
      { name: 'How to use:', value: 
        '1. Attach a .lua file to your message\n' +
        '2. Run the \`.obfuscate\` command\n' +
        '3. Confirm the warning message\n' +
        '4. Receive your obfuscated file'
      }
    )
    .setAuthor({ 
      name: message.author.username, 
      iconURL: message.author.displayAvatarURL({ dynamic: true, size: 256 }) 
    })
    .setFooter({ text: 'Made @ the11view.xyz', iconURL: 'https://t11v.icu/host/ea86ec6e-e9f4-4e34-bfa5-b80dc0f2887a.png' })
    .setTimestamp();
  
  return message.reply({ embeds: [helpEmbed] });
}

async function processDocs(message) {
  const docsEmbed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle('📖 LuaSec V11 - Documentation')
    .setDescription('Full documentation for LuaSec V11 is available at our website.')
    .addFields(
      { name: 'Documentation Link', value: '[https://the11view.xyz/luasec/v/11/docs](https://the11view.xyz/luasec/v/11/docs)' }
    )
    .setAuthor({ 
      name: message.author.username, 
      iconURL: message.author.displayAvatarURL({ dynamic: true, size: 256 }) 
    })
    .setFooter({ text: 'Made @ the11view.xyz', iconURL: 'https://t11v.icu/host/ea86ec6e-e9f4-4e34-bfa5-b80dc0f2887a.png' })
    .setTimestamp();
  
  return message.reply({ embeds: [docsEmbed] });
}

async function Obfuscate(message, attachment) {
  const fileHash = genHash();
  const originalFile = `temp_${message.author.id}_${fileHash}_original.lua`;
  const parsedFile = `temp_${message.author.id}_${fileHash}_parsed.lua`;
  const obfuscatedFile = `luasec-${fileHash}.lua`;
  
  const processingEmbed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle('🔄 Processing File')
    .setDescription('📥 Downloading file...')
    .setAuthor({ 
      name: message.author.username, 
      iconURL: message.author.displayAvatarURL({ dynamic: true, size: 256 }) 
    })
    .setFooter({ text: 'Made @ the11view.xyz', iconURL: 'https://t11v.icu/host/ea86ec6e-e9f4-4e34-bfa5-b80dc0f2887a.png' })
    .setTimestamp();
    
  const processingMessage = await message.channel.send({ embeds: [processingEmbed] });
  
  try {
    await downloadFile(attachment.url, originalFile);
    console.log(`[LuaSec] File downloaded to ${originalFile}`);
    
    await processingMessage.edit({ 
      embeds: [
        processingEmbed.setDescription('🔍 Parsing Lua code...')
      ]
    });
    
    await new Promise((resolve, reject) => {
      const parser = spawn('python', ['parser.py']);
      let errorData = '';
      
      parser.stderr.on('data', (data) => {
        errorData += data.toString();
      });
      
      parser.on('close', (code) => {
        if (code !== 0) {
          reject(new Error(`Parser exited with code ${code}: ${errorData}`));
        } else {
          resolve();
        }
      });
      
      parser.on('error', (error) => {
        reject(error);
      });
      
      parser.stdin.write(`${originalFile}\n`);
      parser.stdin.write(`${parsedFile}\n`);
      parser.stdin.end();
    });
    
    console.log('[LuaSec] File parsed successfully');
    
    await processingMessage.edit({ 
      embeds: [
        processingEmbed.setDescription('🔒 Obfuscating code...')
      ]
    });
    
    await new Promise((resolve, reject) => {
      const obfuscator = spawn('lua', ['main.lua', '--source', parsedFile, '--output', obfuscatedFile]);
      let errorData = '';
      
      obfuscator.stderr.on('data', (data) => {
        errorData += data.toString();
      });
      
      obfuscator.on('close', (code) => {
        if (code !== 0) {
          reject(new Error(`[LuaSec] Obfuscator exited with code ${code}: ${errorData}`));
        } else {
          resolve();
        }
      });
      
      obfuscator.on('error', (error) => {
        reject(error);
      });
    });
    
    console.log('[LuaSec] File obfuscated successfully');
    
    if (!fs.existsSync(obfuscatedFile)) {
      throw new Error('[LuaSec] Obfuscated file was not created');
    }
    
    await processingMessage.edit({ 
      embeds: [
        processingEmbed.setDescription('📤 Uploading result...')
      ]
    });
    
    const fileAttachment = new AttachmentBuilder(obfuscatedFile, { name: `luasec-${fileHash}.lua` });
    
    const successEmbed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle('✅ Obfuscation Complete')
      .setDescription('Your Lua code has been successfully obfuscated with LuaSec V11.')
      .setAuthor({ 
        name: message.author.username, 
        iconURL: message.author.displayAvatarURL({ dynamic: true, size: 256 }) 
      })
      .setFooter({ text: 'Made @ the11view.xyz', iconURL: 'https://t11v.icu/host/ea86ec6e-e9f4-4e34-bfa5-b80dc0f2887a.png' })
      .setTimestamp();
    
    await processingMessage.delete();
    
    const sentMessage = await message.channel.send({
      embeds: [successEmbed],
      files: [fileAttachment]
    });
    
    setTimeout(() => {
      [originalFile, parsedFile].forEach(file => {
        if (fs.existsSync(file)) {
          fs.unlinkSync(file);
          console.log(`[LuaSec] Deleted temporary file: ${file}`);
        }
      });
      
      if (fs.existsSync(obfuscatedFile)) {
        fs.unlinkSync(obfuscatedFile);
        console.log(`[LuaSec] Deleted temporary file: ${obfuscatedFile}`);
      }
    }, 5000);
    
  } catch (error) {
    console.error('[LuaSec] Obfuscation process failed:', error);
    
    await processingMessage.edit({ 
      embeds: [
        new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('❌ Obfuscation Failed')
          .setDescription(`An error occurred during obfuscation: ${error.message || error}`)
          .setAuthor({ 
            name: message.author.username, 
            iconURL: message.author.displayAvatarURL({ dynamic: true, size: 256 }) 
          })
          .setFooter({ text: 'Made @ the11view.xyz', iconURL: 'https://t11v.icu/host/ea86ec6e-e9f4-4e34-bfa5-b80dc0f2887a.png' })
          .setTimestamp()
      ]
    });
    
    [originalFile, parsedFile].forEach(file => {
      if (fs.existsSync(file)) {
        fs.unlinkSync(file);
        console.log(`[LuaSec] Deleted temporary file: ${file}`);
      }
    });
  }
}

bot.once('ready', async () => {
  console.log(`[LuaSec] Logged in as ${bot.user.tag}`);
  console.log('[LuaSec] Bot is ready');
  
bot.user.setPresence({
  activities: [
    { name: 'Porn', type: 3 } // 3 = WATCHING
  ],
  status: 'idle'
});

  
  await Download();
});

bot.login(TOKEN);
